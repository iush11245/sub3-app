﻿using Xunit;
using DataAccessLayer.Repository.MovieRepository;
using DataAccessLayer.DataModels;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DataAccessLayer.Tests
{
    public class MovieRepositoryTests
    {
        private readonly MovieRepository _movieRepository;
        private readonly MovieDBContext _dbContext;

        public MovieRepositoryTests()
        {
            // Set up InMemory DbContext using EF Core
            var options = new DbContextOptionsBuilder<MovieDBContext>()
                .UseInMemoryDatabase(databaseName: "MovieDBTest")
                .EnableSensitiveDataLogging()  // Enable detailed error logging for debugging
                .Options;

            _dbContext = new MovieDBContext(options);
            _movieRepository = new MovieRepository(_dbContext);

            // Seed some sample data into the in-memory database
            var movie = new List<title_basics>
            {
                new title_basics { tconst = "1", primarytitle = "Batman", originaltitle = "The Batman", titletype = "movie", genres = "Action, Adventure", startyear = "2022" },
                new title_basics { tconst = "2", primarytitle = "Batman", originaltitle = "The Dark Knight", titletype = "movie", genres = "Action, Crime", startyear = "2008" },
                new title_basics { tconst = "3", primarytitle = "Batman", originaltitle = "Batman Begins", titletype = "movie", genres = "Action, Adventure", startyear = "2005" },
                new title_basics { tconst = "4", primarytitle = "Superman Returns", originaltitle = "Superman Returns", titletype = "movie", genres = "Action, Adventure", startyear = "2006" }
            };

            _dbContext.title_basics.AddRange(movie);
            _dbContext.SaveChanges();
        }

        [Fact]
        public async Task SearchMoviesBySubString_WithNameAndGenre_ReturnsCorrectMovies()
        {
            // Arrange
            string searchName = "Batman";
            int page = 0;
            int pageSize = 3;

            // Act
            var result = await _movieRepository.SearchMoviesBySubString(searchName, page, pageSize);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(3, result.Count());  // Expecting 3 movies with 'Batman' in the title
            Assert.All(result, movie => Assert.Contains(searchName, movie.primarytitle, StringComparison.OrdinalIgnoreCase));
        }

        [Fact]
        public async Task SearchMoviesByGenre_WithGenre_ReturnsCorrectMovies()
        {
            // Arrange
            string searchGenre = "Adventure";
            int page = 0;
            int pageSize = 2;

            // Act
            var result = await _movieRepository.GetAllMoviesByGenre(searchGenre, page, pageSize);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count());  // Expecting 2 movies with 'Action' genre
            Assert.All(result, movie => Assert.Contains("Action", movie.genres, StringComparison.OrdinalIgnoreCase));
        }
    }
}
