﻿using DataAccessLayer.DataModels;
using DataAccessLayer.Repository.UserRepository;
using Microsoft.AspNetCore.Mvc;
using Moq;
using SUbProject_02_MovieApp.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieApp
{
    public class UserTest
    {
        private readonly Mock<IUserRepository> _userRepositoryMock;
        private readonly UserController _userController;

        public UserTest()
        {
            _userRepositoryMock = new Mock<IUserRepository>();
            _userController = new UserController(_userRepositoryMock.Object);
        }
        [Fact]
        public async Task RegisterUser_UsernameAlreadyExists_ReturnsBadRequest()
        {
            // Arrange
            string userId = "testUser";
            _userRepositoryMock.Setup(repo => repo.getUserbyUsername(userId))
                .ReturnsAsync(new user_info()); // Simulate an existing user

            // Act
            var result = await _userController.RegisterUser(userId, "TestUser", "test@example.com", "password123");

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal("Username is already taken.", badRequestResult.Value);
        }
        [Fact]
        public async Task RegisterUser_NewUsername_ReturnsOkAndCreatesUser()
        {
            // Arrange
            string userId = "newUser";
            string password = "password123";
            string passwordHash = "write something from database that is hashed"; // Example hashed password

            _userRepositoryMock.Setup(repo => repo.getUserbyUsername(userId))
                .ReturnsAsync((user_info)null); // No existing user

            _userRepositoryMock.Setup(repo => repo.AddUser(It.IsAny<user_info>()))
                .Returns(Task.CompletedTask); // Simulate successful user addition

            // Act
            var result = await _userController.RegisterUser(userId, "NewUser", "newuser@example.com", password);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var createdUser = Assert.IsType<user_info>(okResult.Value);
            Assert.Equal(userId, createdUser.user_id);
            Assert.Equal("NewUser", createdUser.username);
            Assert.Equal("newuser@example.com", createdUser.email);
            Assert.Equal(passwordHash, createdUser.user_psw); // Ensure password is hashed
        }
    }
}
