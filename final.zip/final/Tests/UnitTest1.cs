//using DataAccessLayer.DataModels;
//using DataAccessLayer.Repository.UserRepository;
//using Microsoft.EntityFrameworkCore;
//using DataAccessLayer.Repository.NewFolder;
//using DataAccessLayer;
//using Xunit;

//namespace RUC_MovieApp.Tests
//{
//    public class ExtendedRepositoryTests
//    {
//        private DbContextOptions<MovieDBContext> _dbContextOptions;

//        public ExtendedRepositoryTests()
//        {
//            _dbContextOptions = new DbContextOptionsBuilder<MovieDBContext>()
//                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
//                .Options;
//        }

//        private MovieDBContext CreateContextWithData()
//        {
//            var context = new MovieDBContext(_dbContextOptions);

//            //// Seed in-memory database with sample data
//            //context.Users.AddRange(
//            //    new UserInfo { UserId = 1, Username = "testuser", Password = "password123" }
//            //);

//            context.Notes.AddRange(
//                new Notes { NoteId = 1, UserId = "1", Content = "This is a note." }
//            );

//            context.SaveChanges();
//            return context;
//        }

//        [Fact]
//        public async Task LoginUser_WithValidCredentials_ReturnsUser()
//        {
//            // Arrange
//            using var context = CreateContextWithData();
//            var userRepository = new UserRepository(context);

//            // Act
//            var user = await userRepository.LoginUser("testuser", "password123");

//            // Assert
//            Assert.NotNull(user);
//            Assert.Equal("testuser", user.Username);
//        }

//        [Fact]
//        public async Task LoginUser_WithInvalidCredentials_ReturnsNull()
//        {
//            // Arrange
//            using var context = CreateContextWithData();
//            var userRepository = new UserRepository(context);

//            // Act
//            var user = await userRepository.LoginUser("testuser", "wrongpassword");

//            // Assert
//            Assert.Null(user);
//        }

//        [Fact]
//        public async Task AuthenticateUser_WithCorrectPassword_ReturnsTrue()
//        {
//            // Arrange
//            using var context = CreateContextWithData();
//            var userRepository = new UserRepository(context);

//            // Act
//            var isAuthenticated = await userRepository.AuthenticateUser("testuser", "password123");

//            // Assert
//            Assert.True(isAuthenticated);
//        }

//        [Fact]
//        public async Task AuthenticateUser_WithIncorrectPassword_ReturnsFalse()
//        {
//            // Arrange
//            using var context = CreateContextWithData();
//            var userRepository = new UserRepository(context);

//            // Act
//            var isAuthenticated = await userRepository.AuthenticateUser("testuser", "wrongpassword");

//            // Assert
//            Assert.False(isAuthenticated);
//        }

//        [Fact]
//        public async Task AddNote_AddsNoteSuccessfully()
//        {
//            // Arrange
//            using var context = CreateContextWithData();
//            var notesRepository = new NotesRepository(context);
//            var newNote = new Notes { UserId = "1", Content = "This is a new note." };

//            // Act
//            await notesRepository.AddNoteAsync(newNote);
//            var noteExists = context.Notes.Any(n => n.Content == "This is a new note.");

//            // Assert
//            Assert.True(noteExists);
//        }

//        [Fact]
//        public async Task RemoveNote_RemovesNoteSuccessfully()
//        {
//            // Arrange
//            using var context = CreateContextWithData();
//            var notesRepository = new NotesRepository(context);

//            // Verify note exists initially
//            var noteToRemove = context.Notes.FirstOrDefault(n => n.NoteId == 1);
//            Assert.NotNull(noteToRemove);

//            // Act
//            await notesRepository.RemoveNoteAsync(noteToRemove.NoteId);
//            var noteExists = context.Notes.Any(n => n.NoteId == 1);

//            // Assert
//            Assert.False(noteExists);
//        }
//    }
//}
