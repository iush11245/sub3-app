﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.DataModels
{
    public class Genres
    {
        public int Genreid { get; set; }
        public int GenreName { get; set; }
    }
}
