﻿namespace SUbProject_02_MovieApp.DTOModels.MovieDTOs
{
    public class MovieDTO
    {
        public string  tconst { get; set; }
        public string  primarytitle { get; set; }
        public string  startyear { get; set; }
    }
}
