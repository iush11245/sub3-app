﻿namespace SUbProject_02_MovieApp.DTOModels.RatingDTOs
{
    public class UserRatingDTO
    {
        public string tconst { get; set; }
    }
}
