﻿namespace SUbProject_02_MovieApp.DTOModels.NotesDTOs
{
    public class NotesDTO
    {
        //public string Noteid { get; set; }
        public string Userid { get; set; }
        public string tconst { get; set; }
        public string Notes { get; set; }
    }
}
